from os.path import abspath, join, dirname

PROJECT_ROOT_DIR = abspath(join(dirname(__file__), '..'))
